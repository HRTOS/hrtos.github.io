#include<myos.h>
#include<reg52.h>
void my_hrtos()
{
	u8 i;
	ET0=1;
	if(1)i=10;
	ET0=0;
}
