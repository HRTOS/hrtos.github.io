#include<MYOS.h>
#include<reg52.h>
#define HRTOS_LED P0
sbit k=P3^7;
void task1()
{
	while(1)
	{
		HRTOS_LED=0;
		my_hrtos();	 //�ж�����ӿ�
	}
}
void task2()
{
	while(1)
	{
		HRTOS_LED=1;
		my_hrtos();
	}
}
void task3()
{
	while(1)
	{
		HRTOS_LED=3;
		my_hrtos();
	}
}
void task4()
{
	while(1)
	{
		HRTOS_LED=7;
		my_hrtos();
	}
}
void task5()
{
	while(1)
	{
		HRTOS_LED=15;
		my_hrtos();
	}
}
void task0()
{
	while(1)
	{
		HRTOS_LED=255;
		my_hrtos();
	}
}
void task01()
{
	HRTOS_LED=0;
	while(k);
	os_interrupt_exit();	
}
void task02()
{
	HRTOS_LED=18;
	while(k);
	os_interrupt_exit();
}


void my_main()
{
	EA=0;
	EX0=1;
	EX1=1;
	IT0=1;
	IT1=1;
	my_task(task1,0);//ע�ắ��task1,��0�Ų�
	my_task(task2,1);
	my_task(task3,2);
	my_task(task4,3);
	my_task(task5,4);
	my_task(task0,5);
	my_task(task01,14);
	my_task(task02,16);
	os_scheduling(0);//0��ѡ��MyOS���л���ʽ��Ĭ�� 1��HRTOS���л���ʽ
	EA=1;
	while(1);
}

