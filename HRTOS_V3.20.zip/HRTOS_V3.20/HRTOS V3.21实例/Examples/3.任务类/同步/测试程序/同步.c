#include<hrtos.h>
#include<reg52.h>
#define HRTOS_LED P0
sbit HRTOS_K=P3^2;
sbit HRTOS_K1=P3^3;
sbit HRTOS_K2=P3^4;
void os_slab_ov(){}
void task2()
{
	while(HRTOS_K);
	os_semaphore(2);
	while(1)
	{
		HRTOS_LED=1;
	}
}
void task3()
{
	while(HRTOS_K1);
	os_semaphore(2);
	while(1)
	{
		HRTOS_LED=2;
	}
}
void task4()
{
	os_semaphore_control(2,3);
	while(HRTOS_K2);
	os_semaphore(2);
	while(1)
	{
		HRTOS_LED=4;
	}
}

void hrtos_main()
{
	os_task(task4,4,2,2);
	os_task(task2,2,2,2);
	os_task(task3,3,2,2);
	while(1);
}
