#include<hrtos.h>
#include<reg52.h>
#define HRTOS_LED P0
sbit HRTOS_K=P3^2;
void os_slab_ov(){}
void task1()
{
	while(1)
	{
		HRTOS_LED=15;
		while(!HRTOS_K)
		{
			os_task_function(3);
			break;
		}
	}
}
void task2()
{
	while(1)
	{
		HRTOS_LED=2;
	}
}
void task3()
{
	while(1)
	{
		HRTOS_LED=1;
	}
}

void hrtos_main()
{
	os_task(task1,1,8,2);
	os_task(task2,2,5,2);
	os_task(task3,3,2,2);
	while(1);
}
