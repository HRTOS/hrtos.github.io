#include<hrtos.h>
#include<hrtos_NEIBU.h>
#include<reg52.h>
#define HRTOS_LED P0
sbit HRTOS_K=P3^2;
void os_slab_ov(){}
void task2()
{
	while(1)
	{
		HRTOS_LED=1;
	}
}
void task3()
{
	while(1)
	{
		HRTOS_LED=2;
	}
}
void task4()
{
	while(1)
	{
		HRTOS_LED=4;
	}
}

void hrtos_main()
{
	EA=0;
	os_task(task2,2,2,0);
	os_task(task3,3,2,0);
	os_task(task4,4,2,0);
	EA=1;
	os_task_exit();
	EA=0;
	while(1);
}
