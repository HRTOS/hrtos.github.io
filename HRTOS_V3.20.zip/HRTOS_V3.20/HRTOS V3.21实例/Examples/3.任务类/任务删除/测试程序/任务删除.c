#include<hrtos.h>
#include<reg52.h>
#define HRTOS_LED P0
sbit HRTOS_K=P3^2;
sbit HRTOS_K1=P3^3;
sbit HRTOS_K2=P3^4;
extern char os_task_sp(u8 id);
extern unsigned char xdata OS_MEMORY[4];
void os_slab_ov(){}
void task1()
{
	while(1);
}
void task2()
{
	while(1)P0=0;
}
void task3()
{
	while(1);
}
void task5()
{
	while(1);
}

void task4()
{
	u8 i;
	EA=0;
	i=os_task_sp(1);
	HRTOS_LED=i;
	while(HRTOS_K);
	os_task_delete(1);
	os_task(task1,16,8,1);
	os_task(task5,5,2,2);
	i=os_task_sp(16);
	HRTOS_LED=i;
	while(1);
}

void hrtos_main()
{
	EA=0;
	os_task(task2,1,1,1);
	os_task(task4,3,2,2);
	os_task(task3,17,8,2);
	os_task_hang(17);
	os_task_hang(16);
	EA=1;
	while(1);
}
