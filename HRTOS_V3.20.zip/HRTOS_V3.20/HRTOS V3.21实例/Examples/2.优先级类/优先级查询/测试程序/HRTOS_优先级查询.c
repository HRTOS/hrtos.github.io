#include<hrtos.h>
#include<reg52.h>
#define HRTOS_LED P0

void task()
{
	char i;
	 while(1)
	{
		i=os_priority_query(12);
		HRTOS_LED=i; ;
	}
}
void os_slab_ov(){}
void hrtos_main()
{
	os_task(task,12,6,2);
	while(1);
}