#include<hrtos.h>
#include<reg52.h>
#define HRTOS_LED P0
void main()
{
	u16 i;
	HRTOS_LED=0;
	while(1)
	{
		i=65500;
		while(i--)
		{
			os_nop();//��ʱ1��NOP
		}
		HRTOS_LED++;
	}
}
