#include<hrtos.h>
#include<reg52.h>
#define HRTOS_LED P0
sbit HRTOS_K=P3^2;
void os_slab_ov(){}
void task2()
{
	os_wait1(100);//
	while(1)
	{
		HRTOS_LED=0;
	}
}
void task3()
{
	while(1)
	{
		HRTOS_LED=254;
	}
}
void task4()
{
	while(1)
	{
		HRTOS_LED=253;
	}
}

void hrtos_main()
{
	os_task(task2,2,2,2);
	os_task(task3,3,2,2);
	os_task(task4,4,2,2);
	while(1);
}
