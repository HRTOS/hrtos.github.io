#include<hrtos.h>
#include<reg52.h>
#define HRTOS_LED P0
void main()
{
	HRTOS_LED=0;
	while(1)
	{
		TR0=1;
		os_wait2(1000);
		HRTOS_LED++;
	}
	
}
